## Pasos
1) `npm install`
2) MongoDB local en `mongodb://127.0.0.1:27017/academias`
3) Importa `Usuarios` (con Compass o separando por colección)
4) `npm start`
5) Abre `http://localhost:3000/login.html`

*Agregue una nueva coleccion usuarios_auth para la autenticacion del login entonces hay que crearla para poder ejecutarlo.

Usuarios de prueba (password: 123456):
- admin@demo.com → /admin.html
- estudiante@demo.com → /estudiantes.html
- profesor@demo.com → /profesores.html
- tutor@demo.com → /tutores.html
