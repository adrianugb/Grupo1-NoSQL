const express = require('express');
const Estudiantes = require('../models/Estudiantes');
const router = express.Router();
router.get('/me', async (req,res) => {
  if (req.session.user.perfilModelo !== 'Estudiantes') return res.status(403).json({ error:'No es estudiante' });
  const doc = await Estudiantes.findById(req.session.user.perfilId);
  res.json(doc);
});
module.exports = router;
