const express = require('express');
const UsuarioAuth = require('../models/UsuarioAuth');

const router = express.Router();

router.post('/login', async (req,res) => {
  const { correo, password } = req.body;
  const user = await UsuarioAuth.findOne({ correo });
  if (!user) return res.status(401).json({ error: 'Credenciales inválidas' });

  if (user.password !== password) {
    return res.status(401).json({ error: 'Credenciales inválidas' });
  }

  req.session.user = {
    id: String(user._id),
    rol: user.rol,
    perfilId: String(user.perfilId),
    perfilModelo: user.perfilModelo
  };
  res.json({ ok:true, rol: user.rol });
});

router.post('/logout', (req,res) => {
  req.session.destroy(() => res.json({ ok:true }));
});

router.get('/me', (req,res) => {
  if (!req.session.user) return res.status(401).json({ error: 'No autenticado' });
  res.json(req.session.user);
});

module.exports = router;
