const express = require('express');
const UsuarioAuth = require('../models/UsuarioAuth');
const Estudiantes = require('../models/Estudiantes');
const Profesores = require('../models/Profesores');
const Tutores = require('../models/Tutores');
const Administradores = require('../models/Administradores');

const router = express.Router();

function modeloPorRol(rol) {
  if (rol === 'estudiante') return { Modelo: Estudiantes, perfilModelo: 'Estudiantes' };
  if (rol === 'profesor')   return { Modelo: Profesores, perfilModelo: 'Profesores' };
  if (rol === 'tutor')      return { Modelo: Tutores, perfilModelo: 'Tutores' };
  if (rol === 'admin')      return { Modelo: Administradores, perfilModelo: 'Administradores' };
  throw new Error('Rol inválido');
}

router.get('/', async (req,res) => {
  const usuarios = await UsuarioAuth.find({}, { correo:1, rol:1, perfilModelo:1, perfilId:1, fecha_registro:1 }).lean();
  res.json(usuarios);
});

router.post('/', async (req,res) => {
  try {
    const { nombre, correo, password, rol } = req.body;
    if (!nombre || !correo || !password || !rol) return res.status(400).json({ error: 'Campos requeridos' });
    const { Modelo, perfilModelo } = modeloPorRol(rol);

    const perfil = await Modelo.create({ nombre, correo });
    const auth = await UsuarioAuth.create({ correo, password, rol, perfilModelo, perfilId: perfil._id });

    res.status(201).json({ ok:true, usuario: { id: auth._id, correo, rol, perfilModelo, perfilId: perfil._id } });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.put('/:id', async (req,res) => {
  try {
    const { correo, rol, nombre, password } = req.body;
    const user = await UsuarioAuth.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'No encontrado' });

    if (rol && rol !== user.rol) {
      const { Modelo: NuevoModelo, perfilModelo } = modeloPorRol(rol);
      const nuevoPerfil = await NuevoModelo.create({ nombre: nombre || 'Sin nombre', correo: correo || user.correo });
      const OldModel = require('../models/' + user.perfilModelo);
      try { await OldModel.findByIdAndDelete(user.perfilId); } catch {}
      user.perfilId = nuevoPerfil._id;
      user.perfilModelo = perfilModelo;
      user.rol = rol;
    }

    if (correo) user.correo = correo;
    if (password) user.password = password;
    await user.save();

    if (nombre) {
      const PerfilModel = require('../models/' + user.perfilModelo);
      await PerfilModel.findByIdAndUpdate(user.perfilId, { nombre });
    }

    res.json({ ok:true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.delete('/:id', async (req,res) => {
  try {
    const user = await UsuarioAuth.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'No encontrado' });
    const PerfilModel = require('../models/' + user.perfilModelo);
    await PerfilModel.findByIdAndDelete(user.perfilId);
    await user.deleteOne();
    res.json({ ok:true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

module.exports = router;
