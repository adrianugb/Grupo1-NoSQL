const express = require('express');
const Profesores = require('../models/Profesores');
const router = express.Router();
router.get('/me', async (req,res) => {
  if (req.session.user.perfilModelo !== 'Profesores') return res.status(403).json({ error:'No es profesor' });
  const doc = await Profesores.findById(req.session.user.perfilId);
  res.json(doc);
});
module.exports = router;
