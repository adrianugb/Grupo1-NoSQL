const express = require('express');
const Tutores = require('../models/Tutores');
const router = express.Router();
router.get('/me', async (req,res) => {
  if (req.session.user.perfilModelo !== 'Tutores') return res.status(403).json({ error:'No es tutor' });
  const doc = await Tutores.findById(req.session.user.perfilId);
  res.json(doc);
});
module.exports = router;
