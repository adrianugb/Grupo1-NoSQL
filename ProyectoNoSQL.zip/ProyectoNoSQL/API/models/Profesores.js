const { Schema, model } = require('mongoose');
const ProfesoresSchema = new Schema({
  nombre: { type: String, required: true, trim: true },
  correo: { type: String, required: true, trim: true, lowercase: true, unique: true },
  cursos_impartidos: { type: [String], default: [] },
  departamento: { type: String, default: '' },
  activo: { type: Boolean, default: true },
  fecha_registro: { type: Date, default: Date.now }
}, { collection: 'Profesores' });
module.exports = model('Profesores', ProfesoresSchema);
