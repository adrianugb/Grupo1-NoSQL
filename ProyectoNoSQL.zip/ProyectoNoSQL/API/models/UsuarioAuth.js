const { Schema, model, Types } = require('mongoose');
const UsuarioAuthSchema = new Schema({
  correo:       { type: String, required: true, unique: true, lowercase: true, trim: true },
  password:     { type: String, required: true }, 
  rol:          { type: String, enum: ['admin','profesor','tutor','estudiante'], required: true },
  perfilModelo: { type: String, enum: ['Administradores','Profesores','Tutores','Estudiantes'], required: true },
  perfilId:     { type: Types.ObjectId, required: true },
  fecha_registro: { type: Date, default: Date.now }
}, { collection: 'usuarios_auth' });
module.exports = model('UsuarioAuth', UsuarioAuthSchema);
