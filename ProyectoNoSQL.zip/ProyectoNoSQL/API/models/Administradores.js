const { Schema, model } = require('mongoose');
const AdministradoresSchema = new Schema({
  nombre: { type: String, required: true, trim: true },
  correo: { type: String, required: true, trim: true, lowercase: true, unique: true },
  activo: { type: Boolean, default: true },
  fecha_registro: { type: Date, default: Date.now }
}, { collection: 'Administradores' });
module.exports = model('Administradores', AdministradoresSchema);
