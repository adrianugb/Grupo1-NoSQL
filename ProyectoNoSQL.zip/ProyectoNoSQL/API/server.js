const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');

const AuthRouter = require('./routers/AuthRouter');
const AdminUsersRouter = require('./routers/AdminUsersRouter');
const EstudiantesRouter = require('./routers/EstudiantesRouter');
const ProfesoresRouter = require('./routers/ProfesoresRouter');
const TutoresRouter = require('./routers/TutoresRouter');

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/academias');

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use(session({
  secret: 'dev-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 8 * 60 * 60 * 1000 }
}));

function requiereAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'No autenticado' });
  next();
}
function requiereRol(...roles) {
  return (req, res, next) => {
    if (!req.session.user) return res.status(401).json({ error: 'No autenticado' });
    if (!roles.includes(req.session.user.rol)) return res.status(403).json({ error: 'Prohibido' });
    next();
  };
}
app.set('auth', { requiereAuth, requiereRol });

app.use('/api/auth', AuthRouter);
app.use('/api/admin/usuarios', requiereAuth, requiereRol('admin'), AdminUsersRouter);
app.use('/api/estudiantes', requiereAuth, requiereRol('admin','estudiante'), EstudiantesRouter);
app.use('/api/profesores',  requiereAuth, requiereRol('admin','profesor'),  ProfesoresRouter);
app.use('/api/tutores',     requiereAuth, requiereRol('admin','tutor'),     TutoresRouter);

// servir front
app.use('/', express.static(path.join(__dirname, '..', 'Front')));

app.listen(PORT, () => console.log('Server on http://localhost:'+PORT));
